## Todo app

This project contains a simple TODO application
It has the following features - 

- Anyone can create a todo
- Anyone can see their existing todos
- Anyone can mark a todo as done